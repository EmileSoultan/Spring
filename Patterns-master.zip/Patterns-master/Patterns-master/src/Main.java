import java.util.HashMap;
import java.util.Map;

public class Main {

    public static void main(String[] args) {
        Map<String, Integer> words =new HashMap<>();
        words.put("one",1);
        words.get("one");
        System.out.println(words);
    }
}
