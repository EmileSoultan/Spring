package structure_patterns.facade.media_library;

public class Mpeg4CompressionCodec implements Codec{
    public static final String type = "mp4";
}
