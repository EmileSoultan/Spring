package structure_patterns.facade.media_library;

public class OggCompressionCodec  implements Codec{
    public static final String type = "ogg";
}
