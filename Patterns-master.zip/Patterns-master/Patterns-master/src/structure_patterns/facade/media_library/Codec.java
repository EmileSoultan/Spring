package structure_patterns.facade.media_library;

public interface Codec {
}
