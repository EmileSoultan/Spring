package creative_patterns.prototype;

public interface Copyable {
    Object copy();
}
