package creative_patterns.abstract_factory;

public interface Developer {
    void writeCode();
}
