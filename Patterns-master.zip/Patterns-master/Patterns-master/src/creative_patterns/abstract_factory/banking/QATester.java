package creative_patterns.abstract_factory.banking;

import creative_patterns.abstract_factory.Tester;

public class QATester implements Tester {
    @Override
    public void testCode() {
        System.out.println("QA tester tests Java code");
    }
}
