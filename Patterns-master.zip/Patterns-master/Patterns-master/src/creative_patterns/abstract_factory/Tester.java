package creative_patterns.abstract_factory;

public interface Tester {
    void testCode();
}
