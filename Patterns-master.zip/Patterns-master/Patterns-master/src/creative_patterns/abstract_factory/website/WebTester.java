package creative_patterns.abstract_factory.website;

import creative_patterns.abstract_factory.Tester;

public class WebTester implements Tester {
    @Override
    public void testCode() {
        System.out.println("Webtester tests website");
    }
}
