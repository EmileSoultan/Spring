package creative_patterns.builder.builders;

import creative_patterns.builder.entities.CarType;
import creative_patterns.builder.entities.Engine;
import creative_patterns.builder.entities.GPSNavigator;
import creative_patterns.builder.entities.Manual;
import creative_patterns.builder.entities.Transmission;
import creative_patterns.builder.entities.TripComputer;

import java.net.http.WebSocket;

public class CarManualBuilder implements AbstractBuilder {
    private CarType type;
    private int seats;
    private Engine engine;
    private Transmission transmission;
    private TripComputer tripComputer;
    private GPSNavigator gpsNavigator;

    @Override
    public void setCarType(CarType type) {
        this.type = type;
    }

    @Override
    public void setSeats(int seats) {
        this.seats = seats;
    }

    @Override
    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    @Override
    public void setTransmission(Transmission transmission) {
        this.transmission = transmission;
    }

    @Override
    public void setTripComputer(TripComputer tripComputer) {
        this.tripComputer = tripComputer;
    }

    @Override
    public void setGPSNavigator(GPSNavigator gpsNavigator) {
        this.gpsNavigator = gpsNavigator;
    }

    public Manual getResult() {
        return new Manual(type, seats, engine, transmission, tripComputer, gpsNavigator);
    }

}
