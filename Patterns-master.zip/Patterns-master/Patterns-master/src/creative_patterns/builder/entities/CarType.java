package creative_patterns.builder.entities;

public enum CarType {
    CITY_CAR, SPORTS_CAR, SUV
}
