package creative_patterns.factory_method;

public interface OperationalSystem {
    void getOs();
}
