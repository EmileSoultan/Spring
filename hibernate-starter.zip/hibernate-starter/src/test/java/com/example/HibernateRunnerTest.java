package com.example;

import com.example.entity.Chat;
import com.example.entity.Company;
import com.example.entity.LocaleInfo;
import com.example.entity.Payment;
import com.example.entity.PersonalInfo;
import com.example.entity.Profile;
import com.example.entity.Role;
import com.example.entity.User;
import com.example.entity.UserChat;
import com.example.util.HibernateTestUtil;
import com.example.util.HibernateUtil;
import jakarta.persistence.Column;
import jakarta.persistence.LockModeType;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
import lombok.Cleanup;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static java.util.Optional.*;
import static java.util.stream.Collectors.*;

class HibernateRunnerTest {

    @Test
    @Transactional
    void testOptimisticAndPessimistic() {
        try (var sessionFactory = HibernateUtil.buildSessionFactory();
             var session = sessionFactory.openSession()) {
            session.beginTransaction();
            var payment = session.find(Payment.class, 1, LockModeType.PESSIMISTIC_WRITE);
            payment.setAmount(payment.getAmount() + 12);
            session.getTransaction().commit();
        }
    }

    @Test
    void checkHQL() {
        try (var sessionFactory = HibernateTestUtil.buildSessionFactory();
             var session = sessionFactory.openSession()) {
            session.beginTransaction();
//            Map<PersonalInfo, Profile> infoProfileMap = session.createNativeQuery("SELECT u.id,u.company_id,u.dtype,u.firstname, u.lastname, u.birth_date,u.info, " +
//                                                                                  "u.role,u.username, u.projectname, u.lang, p.language, p.street " +
//                                                                                  "FROM users u " +
//                                                                                  "JOIN profile p ON u.id = p.user_id",
//                            User.class)
//                    .getResultStream().collect(Collectors.toMap(User::getPersonalInfo, User::getProfile));
//            System.out.println(infoProfileMap);
//            var list = session.createNativeQuery("SELECT u.* FROM users u " +
//                                                 "JOIN company c ON u.company_id=c.id " +
//                                                 "JOIN profile p ON p.user_id =u.id WHERE c.name = :companyName",
//                    User.class).setParameter("companyName", "Google").list();
//            System.out.println(list);
            session.createQuery("update Profile p  set p.street=:streetName where p.user.id=:userId")
                    .setParameter("streetName", "Utkina 19")
                    .setParameter("userId", 1L)
                    .executeUpdate();
            Map<String, Profile> list = session.createQuery("select u  from  User u " + //+
                                                            "join fetch u.personalInfo pi " +
                                                            "join fetch u.profile p",
                    User.class).getResultStream().collect(toMap(User::getUsername, User::getProfile));
            System.out.println(list);
            Map<String, List<List<User>>> listMap;
            listMap = session.createQuery("select c  from  Company c " +
                                          "join fetch c.users u " +
                                          "join fetch u.profile p ",
                            Company.class).getResultStream()
                    .collect(groupingBy(Company::getName,
                            mapping(Company::getUsers, toList())));
            listMap
                    .forEach((k, v) -> System.out.println((k + ": " + v)));
//            System.out.println(listMap);
            var query = session.createQuery("""
                            select u from User u
                            join u.company c
                             where u.personalInfo.firstname=:firstname and c.name =:companyName
                            """, User.class)
                    .setParameter("firstname", "Ivan")
                    .setParameter("companyName", "Google").list();
            session.getTransaction().commit();
        }

    }
    //.setParameter("companyName", "Google").list();
//            System.out.println(list);

    @Test
    void checkLocale() {
        try (var sessionFactory = HibernateTestUtil.buildSessionFactory();
             var session = sessionFactory.openSession()) {
            session.beginTransaction();
            var company = session.get(Company.class, 1);
            company.getLocales().add(LocaleInfo.of("ru", "Описание на русском"));
            company.getLocales().add(LocaleInfo.of("eng", "English description"));
            session.getTransaction().commit();
//            session.createQuery("update Company.locales c set ")
        }
    }

    @Test
    void checkH2() {
        try (var sessionFactory = HibernateUtil.buildSessionFactory();
             var session = sessionFactory.openSession()) {
            session.beginTransaction();
            var fall = Company.builder().name("Fall").build();
//            session.persist(google);
//            var company = session.find(Company.class, 2);
//            var programmer = Programmer.builder()
//                    .username("flow@gmail.com")
//                    .personalInfo(PersonalInfo.builder()
//                            .firstname("Elena")
//                            .lastname("Ivanova")
//                            .birthDate(new BirthDate(LocalDate.of(1997, 7, 9)))
//                            .build())
//                    .language(Language.C)
//                    .role(Role.USER)
//                    .info("""
//                            {
//                              "ru": "Елена",
//                              "address": "Саратов"
//                            }
//                            """)
//                    .company(fall)
//                    .build();
//            session.persist(programmer);
//            var programmerProfile = Profile.builder()
//                    .language("ru")
//                    .street("Северная 16")
//                    .user(programmer)
//                    .build();
////            session.persist(programmerProfile);
//            var manager = Manager.builder()
//                    .username("kilew@gmail.com")
//                    .personalInfo(PersonalInfo.builder()
//                            .firstname("Svetlana")
//                            .lastname("Orlova")
//                            .birthDate(new BirthDate(LocalDate.of(1998, 4, 21)))
//                            .build())
//                    .projectName("Accounting")
//                    .role(Role.ADMIN)
//                    .info("""
//                            {
//                              "ru": "Светлана",
//                              "address": "Самара"
//                            }
//                            """)
//                    .company(fall)
//                    .build();
//            session.persist(manager);
//            var managerProfile = Profile.builder()
//                    .user(manager)
//                    .language("ru")
//                    .street("Речная 19")
//                    .build();
////            session.persist(managerProfile);
//            fall.setUsers(List.of(manager, programmer));
//            session.persist(fall);
//            session.getTransaction().commit();
        }
    }

    @Test
    void manyToMany() {
        try (var sessionFactory = HibernateUtil.buildSessionFactory();
             var session = sessionFactory.openSession()) {
            session.beginTransaction();
            var programmer = session.find(User.class, 1L);
            var manager = session.find(User.class, 2L);
            var managers = Chat.builder().name("managers2").build();
            var programmers = Chat.builder().name("programmers2").build();
            session.persist(managers);
            session.persist(programmers);
//            var managerChat = session.find(Chat.class, 1L);
//            var programmerChat = session.find(Chat.class, 2L);
            var managersChat = UserChat.builder()
                    .chat(managers)
                    .user(manager)
                    .build();
            var programmersChat = UserChat.builder()
                    .chat(programmers)
                    .user(programmer)
                    .build();
            programmersChat.setCreatedBy(programmer.getUsername());
            programmersChat.setCreatedAt(Instant.now());
            managersChat.setCreatedBy(manager.getUsername());
            managersChat.setCreatedAt(Instant.now());
            session.persist(managersChat);
            session.persist(programmersChat);
            session.getTransaction().commit();
        }
    }

    @Test
    void checkOneToOne() {
        try (var sessionFactory = HibernateUtil.buildSessionFactory();
             var session = sessionFactory.openSession()) {
            session.beginTransaction();
            var user = session.find(User.class, 1L);
            var payment = Payment.builder()
                    .receiver(user)
                    .amount(3700)
                    .build();
            session.persist(payment);
//            var profile1 = session.find(Profile.class, 1L);
            session.getTransaction().commit();
        }
    }

    @Test
    void checkLazyInitialization() {
        Company company = null;
        try (var sessionFactory = HibernateUtil.buildSessionFactory();
             var session = sessionFactory.openSession()) {
            session.beginTransaction();
            company = session.find(Company.class, 1);
            System.out.println(company.getUsers());
            session.getTransaction().commit();
        }
    }

    @Test
    void addUserToNewCompany() {
        try (var sessionFactory = HibernateUtil.buildSessionFactory();
             var session = sessionFactory.openSession()) {
            session.beginTransaction();
            var company = Company.builder().name("Amazon").build();
            var company1 = Company.builder().name("Microsoft").build();
            var company2 = Company.builder().name("Tesla").build();
//            session.refresh(user);
//            var company = session.find(Company.class, 1);
//            company.addUser(user);
//            user.setUsername("Amazon");
//            session.flush();
            session.persist(company);
            session.persist(company1);
            session.persist(company2);
            session.getTransaction().commit();
        }
    }

    @Test
    void oneToMany() {
        @Cleanup var sessionFactory = HibernateUtil.buildSessionFactory();
        @Cleanup var session = sessionFactory.openSession();
//        var programmer = Programmer.builder().username("petr@mail.com").build();
        session.beginTransaction();
        var company = session.find(Company.class, 1L);
//        user.setUsername("petr1@mail.com");
//        session.refresh(user);
//        System.out.println(user);
//        System.out.println(user.getUserChats());
        var users = company.getUsers();
//        var name = users.get();
        System.out.println(users);
//        session.evict(user);
//        company.getUsers().forEach(System.out::println);
        session.getTransaction().commit();

    }

    @Test
    void checkReflectionApi() {
        var user = User.builder()
                .username("tim@gmail.com")
                .personalInfo(PersonalInfo.builder()
                        .firstname("Tim")
                        .lastname("Smith")
                        .birthDate((LocalDate.of(1997, 7, 9)))
                        .build())
                .role(Role.USER)
                .info("""
                             {
                          "name": "Tim",
                         "id": 5
                            }
                        """)
                .company(Company.builder()
                        .name("Google")
                        .build())
                .build();
        String sql = """
                INSERT
                INTO %s
                (%s)
                VALUES (%s)
                """;
        var tableName = ofNullable(user.getClass().getAnnotation(Table.class))
                .map(Table::name)
                .orElse(user.getClass().getName());
        var declaredFields = user.getClass().getDeclaredFields();
        var columnNames = Arrays.stream(declaredFields)
                .map(field -> ofNullable(field.getAnnotation(Column.class))
                        .map(Column::name).orElse(field.getName())).collect(joining(", "));
        var columnValues = Arrays.stream(declaredFields).map(field -> "?").collect(joining(", "));
        System.out.printf((sql) + "%n", tableName, columnNames, columnValues);
    }

}