INSERT INTO test.public.users (username, birth_date, firstname, lastname)
VALUES ('asd', 2020-2-3, 'asd','asdsadssa');