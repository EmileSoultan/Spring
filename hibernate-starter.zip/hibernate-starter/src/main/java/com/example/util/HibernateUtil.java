package com.example.util;

import com.example.converter.BirthdateConverter;
import com.example.entity.*;
import com.example.entity.Audit;
import com.example.listener.AuditTableListener;
import lombok.experimental.UtilityClass;
import org.hibernate.SessionFactory;
import org.hibernate.boot.model.naming.CamelCaseToUnderscoresNamingStrategy;
import org.hibernate.cfg.Configuration;
import org.hibernate.event.service.spi.EventListenerRegistry;
import org.hibernate.event.spi.EventType;
import org.hibernate.internal.SessionFactoryImpl;

import java.util.Objects;

@UtilityClass
public class HibernateUtil {
    public static SessionFactory buildSessionFactory(){
        var configuration = buildConfiguration();
        configuration.configure();
//        SessionFactory sessionFactory = configuration.buildSessionFactory();
//        registerListeners(sessionFactory);
        return configuration.buildSessionFactory();
    }

    private static void registerListeners(SessionFactory sessionFactory) {
        var sessionFactoryImpl = sessionFactory.unwrap(SessionFactoryImpl.class);
        var listenerRegistry = sessionFactoryImpl.getServiceRegistry().getService(EventListenerRegistry.class);
        var auditTableListener = new AuditTableListener();
        Objects.requireNonNull(listenerRegistry).appendListeners(EventType.POST_INSERT, auditTableListener);
        listenerRegistry.appendListeners(EventType.PRE_DELETE, auditTableListener);
    }

    public static Configuration buildConfiguration() {
        var configuration = new Configuration();
        configuration.addAnnotatedClass(User.class);
//        configuration.addAnnotatedClass(PersonalInfo.class);
//        configuration.addAnnotatedClass(Programmer.class);r
//        configuration.addAnnotatedClass(Manager.class);
        configuration.addAnnotatedClass(Company.class);
        configuration.addAnnotatedClass(Profile.class);
        configuration.addAnnotatedClass(Chat.class);
        configuration.addAnnotatedClass(UserChat.class);
        configuration.addAnnotatedClass(Payment.class);
        configuration.addAnnotatedClass(Audit.class);
        configuration.setPhysicalNamingStrategy(new CamelCaseToUnderscoresNamingStrategy());
        configuration.addAttributeConverter(new BirthdateConverter(), true);
        return configuration;
    }
}
