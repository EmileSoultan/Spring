package com.example.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class StringUtils {

    public static final String SPACE = " ";
}
