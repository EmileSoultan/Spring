package com.example.service;

import com.example.dao.UserRepository;
import com.example.dto.UserCreateDto;
import com.example.dto.UserReadDto;
import com.example.mapper.UserCreateMapper;
import com.example.mapper.UserReadMapper;
import lombok.RequiredArgsConstructor;

import java.util.Optional;

@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final UserReadMapper userReadMapper;
    private final UserCreateMapper userCreateMapper;

    public Long create(UserCreateDto userDto) {
        var user = userCreateMapper.mapFrom(userDto);
        return userRepository.save(user).getId();
    }

    public boolean delete(Long id) {
        var maybeUser = userRepository.findById(id);
        maybeUser.ifPresent(userRepository::delete);
//        System.out.println(maybeUser.isPresent());
        return maybeUser.isPresent();
    }

    public Optional<UserReadDto> findById(Long id) {
        return userRepository.findById(id).map(userReadMapper::mapFrom);

    }
}
