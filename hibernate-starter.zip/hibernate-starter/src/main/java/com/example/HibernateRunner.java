package com.example;

import com.example.dao.CompanyRepository;
import com.example.dao.PaymentRepository;
import com.example.dao.UserRepository;
import com.example.dto.UserCreateDto;
import com.example.entity.Payment;
import com.example.entity.PersonalInfo;
import com.example.entity.Role;
import com.example.mapper.CompanyReadMapper;
import com.example.mapper.UserCreateMapper;
import com.example.mapper.UserReadMapper;
import com.example.service.UserService;
import com.example.util.HibernateUtil;
import com.example.util.TestDataImporter;
import jakarta.persistence.LockModeType;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.lang.reflect.Proxy;
import java.time.LocalDate;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static java.lang.Thread.*;

@Slf4j
public class HibernateRunner {

    //    private static final Logger log = LoggerFactory.getLogger(HibernateRunner.class);
    public static void main(String[] args) {
        try (var sessionFactory = HibernateUtil.buildSessionFactory()) {
            var executorService = getThreadPoolExecutor(sessionFactory);
            System.out.println(executorService);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
//        // Ожидаем завершения всех задач в ThreadPoolExecutor
    }
//    public static String noSpace(final String x) {
//        return x.replace("\\w", "");
//    }
//    public static String bmi(double weight, double height) {
//        var bmi = weight * Math.pow(height, 2);
//        if (bmi <= 18.5) {
//            return "Underweight";
//        } else if (bmi <= 25.0) {
//            return "Normal";
//        } else if (bmi <= 30.0) {
//            return "Overweight";
//        } else  {
//            return "Obese";
//        }
//    }
//
//    public static String evenOrOdd(int number) {
//        return number % 2 == 0 ? "Even" : "Odd";
//        // Place code here;
//    }

    private static ExecutorService getThreadPoolExecutor(SessionFactory sessionFactory) throws InterruptedException {
        var session = (Session) Proxy.newProxyInstance(SessionFactory.class.getClassLoader(), new Class[]{Session.class},
                (proxy, method, args1) -> method.invoke(sessionFactory.getCurrentSession(), args1));
        var userCreateDto = new UserCreateDto(PersonalInfo.builder()
                .firstname("Josh")
                .lastname("Owen")
                .birthDate(LocalDate.of(1965, 5, 9))
                .build(),
                "jomnygmail",
                """
                           {
                             "Occupancy": "Manager",
                             "id": 25
                           }
                        """,
                Role.USER,
                1
        );
        var userService = getUserService(session);
        var executorService = Executors.newFixedThreadPool(1);
        // Выполняем 1000 запросов в ThreadPoolExecutor
        for (int i = 0; i < 1; i++) {
            Future<?> submit = executorService.submit(() -> {
//                    TestDataImporter.importData(sessionFactory);
                System.out.println(currentThread().getName() + " from threadPool took a task");
                session.beginTransaction();
                var payment = session.find(Payment.class, 1, LockModeType.PESSIMISTIC_READ);
                payment.setAmount(payment.getAmount()+10);
                session.getTransaction().commit();

            });

        }
        executorService.shutdown();
        try {
            executorService.awaitTermination(1, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return executorService;

    }

    private static UserService getUserService(Session session) {
        var paymentRepository = new PaymentRepository(session);
        var companyRepository = new CompanyRepository(session);
        var userRepository = new UserRepository(session);
        var companyReadMapper = new CompanyReadMapper();
        var userCreateMapper = new UserCreateMapper(companyRepository);
        var userReadMapper = new UserReadMapper(companyReadMapper);
        return new UserService(userRepository, userReadMapper, userCreateMapper);
    }
}

