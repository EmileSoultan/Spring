package com.example;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        List<Integer> listNumber = List.of(0, 1, 1, 0, 2, 4, 5, 0, 2, 3, 0, 4, 5);
//            for (Integer integer : listNumber) {
//            if (integer == 0) {
//                integers.add(integer);
//            }
//        }
        System.out.println(getList(listNumber));
        char[] ints = {'c', 'c', 'a', 'b', 'd', 'd', 'e', 'e', 'b'};
        String[] words = {"Race", "acer", "Night", "night", "angle", "angel", "Thing", "thIng"};
//        Map<Integer, String> result = listNumber.stream()
//                .collect(Collectors.toMap(Function.identity(),
//                        a -> (a % 2 == 0) ? "even" : "odd"));
//        System.out.println(result);
//        HashMap<String, List<Integer>> result2 = Stream.generate(() -> new Random().nextInt(-100, 100)).limit(10)
//                .collect(Collectors.toMap(a -> (a % 2 == 0) ? "even" : "odd",
//                        List::of, (a, b) -> {
//                            List<Integer> list = new ArrayList<>(a);
//                            list.addAll(b);
//                            return list;
//                        }, HashMap::new));
//        System.out.println(result2);
//        Map<Integer, Integer> frequencyMap = new HashMap<>();
//        for (int number : listNumber) {
//            frequencyMap.put(number, frequencyMap.getOrDefault(number, 0) + 1);
//        }
//        System.out.println(frequencyMap);
//// Find the first element with a frequency of 1
//        int firstUniqueElement = -1;
//        for (int number : listNumber) {
//            if (frequencyMap.get(number) == 1) {
//                firstUniqueElement = number;
//                break;
//            }
//        }
//        System.out.println(firstUniqueElement);
// Создаем массив для подсчета частоты каждого элемента
        char[] frequencyArray = new char[122];
// Подсчитываем частоту каждого элемента в списке
//        for (int i : ints) {
//            frequencyArray[i]++;
//        }
        for (int i = 0; i < ints.length; i++) {
            frequencyArray[ints[i]]++;

        }
// Находим первый уникальный элемент
        char firstUniqueElement = '\0';
        for (char ch : ints) {
            if (frequencyArray[ch] == 1) {
                firstUniqueElement = ch;
                break;
            }
        }
        System.out.println("Первый уникальный элемент: " + firstUniqueElement);
    }

    private static List<Integer> getList(List<Integer> listNumber) {
        List<Integer> integers = new ArrayList<>(listNumber.size());
        for (Integer integer : listNumber) {
            if (integer != 0) {
                integers.add(integer);

            }

        }
        return integers;
    }
}