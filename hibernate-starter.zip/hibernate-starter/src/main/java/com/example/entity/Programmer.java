package com.example.entity;
//@EqualsAndHashCode(callSuper = true)
//@Data
//@ToString(callSuper = true)
//@AllArgsConstructor
//@NoArgsConstructor
//@Entity
////@PrimaryKeyJoinColumn(name = "id")
//public class Programmer extends User {
//
//    @Enumerated(EnumType.STRING)
//    @Column(name = "lang")
//    private Language language;
//
//    @Builder
//    public Programmer(Long id, String username, PersonalInfo personalInfo, String info, Role role, Company company, Profile profile, List<UserChat> userChats, List<Payment> payments, Language language) {
//        super(id, username, personalInfo, info, role, company, profile, userChats, payments);
//        this.language = language;
//    }
//
//}

