package com.example.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Embeddable
@Data
public class PersonalInfo   {

    private String firstname;
    private String lastname;
//    @Convert(converter = BirthdateConverter.class)
    @NotNull
    private LocalDate birthDate;
}
