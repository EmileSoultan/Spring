package com.example.entity;
//@EqualsAndHashCode(callSuper = true)
//@Data
//@ToString(callSuper = true)
//@NoArgsConstructor
//@AllArgsConstructor
//@Entity
////@PrimaryKeyJoinColumn(name = "id")
////public class Manager extends User {
////    private String projectName;
////
////    @Builder
////
////    public Manager(Long id, String username, PersonalInfo personalInfo, String info, Role role, Company company, Profile profile, List<UserChat> userChats, List<Payment> payments, String projectName) {
////        super(id, username, personalInfo, info, role, company, profile, userChats, payments);
////        this.projectName = projectName;
////    }
////}
