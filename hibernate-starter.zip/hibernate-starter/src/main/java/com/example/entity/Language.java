package com.example.entity;

public enum Language {
    JAVA, C, RUBY
}
