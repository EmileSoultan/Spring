package com.example.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Embeddable
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor
public class LocaleInfo {
    private String lang;
    @Column(length = 128)
    private String description;
}
