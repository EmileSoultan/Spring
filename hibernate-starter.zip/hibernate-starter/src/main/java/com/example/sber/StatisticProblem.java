package com.example.sber;

import lombok.AllArgsConstructor;
import lombok.Data;


import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public  class StatisticProblem {
    public Map<String, Statistic> collectStatistic(List<BrokerageAccount> accounts) {

        return null;
    }

    /**
     * Статистика
     */
    @Data
    @AllArgsConstructor
    public static class Statistic {
        private long count;
        private BigDecimal sum;
    }

    /**
     * Брокерский счет
     */
    @Data
    public static class BrokerageAccount {
        private String accountNumber;
        private BigDecimal valuation;
        private List<Security> securities;
    }

    /**
     * Ценная бумага. Пример, Security(ticker=SBER, count=10, money=2303.03)
     */
    @Data
    public static class Security {
        private BigDecimal pricePerSecurity;
        private String ticker;
        private int count;
        private BigDecimal money= pricePerSecurity.multiply(BigDecimal.valueOf(count));
    }
}