package com.example.listener;

import com.example.entity.Audit;
import org.hibernate.event.spi.AbstractPreDatabaseOperationEvent;
import org.hibernate.event.spi.PostInsertEvent;
import org.hibernate.event.spi.PostInsertEventListener;
import org.hibernate.event.spi.PreDeleteEvent;
import org.hibernate.event.spi.PreDeleteEventListener;
import org.hibernate.persister.entity.EntityPersister;

import java.io.Serializable;

public class AuditTableListener  implements PreDeleteEventListener, PostInsertEventListener  {



    @Override
    public boolean onPreDelete(PreDeleteEvent event) {
        auditEntity(event);
        return false;
    }

    @Override
    public void onPostInsert(PostInsertEvent event) {
        if (event.getEntity().getClass() != Audit.class) {
            var audit = Audit.builder()
                    .entityId((Serializable) event.getId())
                    .entityName(String.valueOf(event.getPersister().getEntityName()))
                    .entityContent(event.getEntity().toString())
                    .operation(Audit.Operation.INSERT)
                    .build();
            event.getSession().persist(audit);
        }
    }

    private static void auditEntity(AbstractPreDatabaseOperationEvent event) {
        if (event.getEntity().getClass() != Audit.class) {
            var audit = Audit.builder()
                    .entityId((Serializable) event.getId())
                    .entityName(String.valueOf(event.getPersister().getEntityName()))
                    .entityContent(event.getEntity().toString())
                    .operation(Audit.Operation.DELETE)
                    .build();
            event.getSession().persist(audit);
        }
    }

    @Override
    public boolean requiresPostCommitHandling(EntityPersister persister) {
        return false;
    }
}
