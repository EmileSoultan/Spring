package com.example.listener;

import com.example.entity.AuditableEntity;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import lombok.NonNull;

import java.time.Instant;

public class AuditDataListener {

    @PrePersist
    public void prePersist(@NonNull AuditableEntity<?> entity) {
        entity.setCreatedAt(Instant.now());
        entity.setCreatedBy(Thread.currentThread().getName());
    }

    @PreUpdate
    public void PreUpdate(@NonNull AuditableEntity<?> entity) {
        entity.setCreatedAt(Instant.now());
        entity.setCreatedBy(Thread.currentThread().getName());
    }
}
