package com.example.dto;

import com.example.entity.PersonalInfo;
import com.example.entity.Role;
import jakarta.validation.Valid;

public record UserCreateDto(PersonalInfo personalInfo,
                            @Valid
                            String username,
                            String info,
                            Role role,
                            Integer companyId) {

}
