package com.example.dto;

import com.example.entity.PersonalInfo;
import com.example.entity.Role;

public record UserReadDto(Long id,
                          String username,
                          PersonalInfo personalInfo,
                          String info,
                          Role role,
                          CompanyReadDto company) {

}
