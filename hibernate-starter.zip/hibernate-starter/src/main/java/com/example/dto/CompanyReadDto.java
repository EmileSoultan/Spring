package com.example.dto;

import com.example.entity.LocaleInfo;

import java.util.List;

public record CompanyReadDto(Integer id,
                             String name,
                             List<LocaleInfo> locales) {

}
