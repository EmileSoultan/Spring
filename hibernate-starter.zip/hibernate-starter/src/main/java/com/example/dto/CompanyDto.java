package com.example.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;
import lombok.Value;

import java.util.Objects;

@Value
public class CompanyDto {

    String name;
    Double amount;

}
