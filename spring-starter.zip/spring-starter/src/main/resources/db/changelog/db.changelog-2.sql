--liquibase formatted sql

--changeset esultanov:1
CREATE TABLE IF NOT EXISTS payment_aud
(
    id          BIGINT  NOT NULL,
    rev         INTEGER NOT NULL,
    revtype     SMALLINT,
    created_at  TIMESTAMP(6) WITH TIME ZONE,
    created_by  VARCHAR(32),
    modified_at TIMESTAMP(6) WITH TIME ZONE,
    modified_by VARCHAR(32),
    amount      INTEGER,
    receiver_id BIGINT,
    PRIMARY KEY (rev, id)
);

--changeset esultanov:2
CREATE TABLE IF NOT EXISTS revision
(
    id        SERIAL NOT NULL,
    timestamp BIGINT,
    PRIMARY KEY (id)
);

--changeset esultanov:3
CREATE TABLE IF NOT EXISTS users_aud
(
    id          BIGINT  NOT NULL,
    rev         INTEGER NOT NULL,
    revtype     SMALLINT,
    created_at  TIMESTAMP(6) WITH TIME ZONE,
    created_by  VARCHAR(32),
    modified_at TIMESTAMP(6) WITH TIME ZONE,
    modified_by VARCHAR(32),
    birth_date  DATE,
    firstname   VARCHAR(64),
    lastname    VARCHAR(64),
    role        VARCHAR(255) CHECK (role IN ('ADMIN', 'USER')),
    username    VARCHAR(64),
    company_id  INTEGER,
    PRIMARY KEY (rev, id)
)
