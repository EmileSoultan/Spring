--liquibase formatted sql

--changeset esultanov:1
CREATE TABLE IF NOT EXISTS company
(
    id   SERIAL PRIMARY KEY,
    name VARCHAR(64) NOT NULL UNIQUE
);

--changeset esultanov:2
CREATE TABLE IF NOT EXISTS company_locale
(
    company_id  INT REFERENCES company (id) ON DELETE CASCADE,
    lang        VARCHAR(2),
    description VARCHAR(255) NOT NULL,
    PRIMARY KEY (company_id, lang)
);

--changeset esultanov:3
CREATE TABLE IF NOT EXISTS users
(
    id          BIGSERIAL PRIMARY KEY,
    username    VARCHAR(64) NOT NULL UNIQUE,
    birth_date  DATE,
    firstname   VARCHAR(64),
    lastname    VARCHAR(64),
    role        VARCHAR(32),
    created_at  TIMESTAMP(6) WITH TIME ZONE,
    created_by  VARCHAR(32),
    modified_at TIMESTAMP(6) WITH TIME ZONE,
    modified_by VARCHAR(32),
    company_id  INT REFERENCES company (id)
);

--changeset esultanov:4
CREATE TABLE IF NOT EXISTS payment
(
    id          BIGSERIAL PRIMARY KEY,
    amount      INT    NOT NULL,
    created_at  TIMESTAMP(6) WITH TIME ZONE,
    created_by  VARCHAR(32),
    modified_at TIMESTAMP(6) WITH TIME ZONE,
    modified_by VARCHAR(32),
    receiver_id BIGINT NOT NULL REFERENCES users (id) ON DELETE CASCADE
);
--changeset esultanov:5
CREATE TABLE IF NOT EXISTS chat
(
    id   BIGSERIAL PRIMARY KEY,
    name VARCHAR(64) NOT NULL UNIQUE

);
--changeset esultanov:6
CREATE TABLE IF NOT EXISTS users_chat
(
    id      BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users (id) ON DELETE CASCADE ,
    chat_id BIGINT NOT NULL REFERENCES chat (id) ON DELETE CASCADE ,
    UNIQUE (user_id, chat_id)
);