package org.example.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Slf4j
@Aspect
@Component
public class FirstAspect {


//    @within - check annotation on class level - Проверяет аннотацию на уровне класса


    @Pointcut("@within(org.springframework.stereotype.Controller)")
    public void isControllerLayer() {
    }

    /*

    within - check class type name - Проверяет тип класса по имени
     */
    @Pointcut("within(org.example.service.*Service)")
    public void isServiceLayer() {
    }

    /*
    this - check AOP proxy class type
    target - check target object class type
     */
    @Pointcut("this(org.springframework.data.repository.Repository)")
//    @Pointcut("target(org.springframework.data.repository.Repository)")
    public void isRepository() {
    }

    /*
    @annotation - check annotation on method level -> Проверяет аннотацию на уровне методов

     */
    @Pointcut("isControllerLayer() && @annotation(org.springframework.web.bind.annotation.GetMapping)")
    public void hasGetMapping() {
    }

    /*
    args -> check method param type - Проверяет аргумент параметра

    * - any param type -> Любой один тип параметра

    .. - any count of params type -> Любое количество параметров

     */
    @Pointcut("isControllerLayer() && args(org.springframework.ui.Model,..))")
    public void hasModelParam() {
    }

    /* @args -> check annotation on the param type - Проверяет аннотацию над типом параметра

     * - any param type -> Любой один тип параметра
     .. - any count of params type -> Любое количество параметров

    */
    @Pointcut()
    public void hasUserInfoAnnotation() {
    }

    /*
    bean -> check bean name - проверяет по названию бина
     */
    @Pointcut("bean(*Service)")
    public void isServiceBean() {
    }

    /*

     */
    @Pointcut("execution(public * org.example.service.*Service.findById(*))")
    public void anyFindIdServiceMethod() {
    }

    @Before(value = "anyFindIdServiceMethod()")
    public void addLogging() {
        log.info("invoked findById method");
    }

}
