package org.example.service;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.bpp.Auditing;
import org.example.bpp.Transaction;
import org.example.dto.CompanyReadDto;
import org.example.listener.entity.AccessType;
import org.example.listener.entity.EntityEvent;
import org.example.mapper.CompanyReadMapper;
import org.example.repository.CompanyRepository;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
//@RequiredArgsConstructor
@Slf4j
public class CompanyService implements Serializable {

    private final CompanyRepository companyRepository;

    private final CompanyReadMapper companyReadMapper;
    private final ApplicationEventPublisher eventPublisher;

    {
        log.info("Non-static block");
    }

    public void getLog() {
        log.info("ServiceBean");
    }

    public CompanyService(CompanyRepository companyRepository, CompanyReadMapper companyReadMapper, ApplicationEventPublisher eventPublisher) {
        this.companyRepository = companyRepository;
        log.info("companyRepositoryBean injection");
        this.companyReadMapper = companyReadMapper;
        this.eventPublisher = eventPublisher;
    }

    @PostConstruct
    void init() {
        log.info("init method");
    }

    public Optional<CompanyReadDto> findById(Integer id) {
        return companyRepository.findById(id).map(entity -> {
            eventPublisher.publishEvent(new EntityEvent(AccessType.READ, entity));
            return companyReadMapper.map(entity);
        });

    }

    public List<CompanyReadDto> findAll() {
        return companyRepository.findAll().stream().map(companyReadMapper::map).toList();
    }
}
