package org.example.dto;

public interface PersonalInfo2 {

    String getFirstname();

    String getLastname();

    String getBirthdate();
}
