package org.example.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Setter;
import lombok.Value;
import lombok.experimental.FieldNameConstants;
import org.example.entity.Role;
import org.example.validation.UserInfo;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Value
@FieldNameConstants
@UserInfo
public class UserCreateEditDto {

    @Email
    String username;
    String rawPassword;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    LocalDate birthDate;

    @NotBlank
    @Size(min = 3, max = 64)
    String firstname;

    @NotBlank
    @Size(min = 4, max = 128)
    String lastname;

    @NotNull
    Role role;
    Integer companyId;
}
