package org.example.dto;

public record CompanyReadDto(Integer id, String name) {
}
