package org.example.dto;

import org.example.entity.Company;

import java.time.LocalDate;
import java.util.Optional;

public record UserFilter(String firstname,
                         String lastname,
                         LocalDate birthdate
) {

}
