package org.example.bpp;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class TransactionBeanPostProcessor implements BeanPostProcessor {

    private final Map<String, Class<?>> transactionsBeans = new HashMap<>();

    {
        log.info("TransactionBeanPostProcessor");
    }

    public TransactionBeanPostProcessor() {
        log.info("TransactionBeanPostProcessor constructor");
    }

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        if (bean.getClass().isAnnotationPresent(Transaction.class)) {
            transactionsBeans.put(beanName, bean.getClass());
            log.info("transaction process Before init");
        }
        return bean;
    }

    @Primary
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> beanClass = transactionsBeans.get(beanName);
        if (beanClass != null) {
            return Proxy.newProxyInstance(beanClass.getClassLoader(), beanClass.getInterfaces(),
                    (proxy, method, args) -> {
                        log.info("Open transaction");
                        try {
                            return method.invoke(bean, args);

                        } finally {
                            log.info("Close transaction");

                        }
                    });
        }
        return bean;
    }

    @PostConstruct
    void init() {
        log.info("post construct Init method");
    }
}
