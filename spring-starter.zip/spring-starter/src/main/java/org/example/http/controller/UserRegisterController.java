package org.example.http.controller;

import lombok.RequiredArgsConstructor;
import org.example.dto.UserCreateEditDto;
import org.example.entity.Role;
import org.example.service.CompanyService;
import org.example.service.UserService;
import org.springframework.security.core.annotation.CurrentSecurityContext;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/registration")
@RequiredArgsConstructor
public class UserRegisterController {

    private final CompanyService companyService;
    private final UserService userService;


    @GetMapping
    public String registration(Model model, UserCreateEditDto user) {
        model.addAttribute("user", user);
        model.addAttribute("roles", Role.USER);
        model.addAttribute("companies", companyService.findAll());
        return "user/registration";
    }

    @PostMapping("/save")
//    @ResponseStatus(HttpStatus.PERMANENT_REDIRECT)
    public String save(UserCreateEditDto user, @CurrentSecurityContext SecurityContext securityContext) {
        userService.create(user);
        return "redirect:/login";
    }
}
