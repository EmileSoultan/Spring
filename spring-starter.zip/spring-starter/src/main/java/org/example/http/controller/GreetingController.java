package org.example.http.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.example.dto.UserReadDto;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.HttpRequestHandlerAdapter;

@Controller
@RequestMapping(value = "/api/v1")
public class GreetingController {

    @GetMapping(value = "/hello")
    public ModelAndView hello(ModelAndView modelAndView, HttpServletRequest request) {
        modelAndView.setViewName("greeting/hello");
//        modelAndView.addObject("user", new UserReadDto(1L, "Ivan"));
        return modelAndView;

    }
    @RequestMapping(value = "/bye", method = RequestMethod.GET)

    public ModelAndView bye(ModelAndView modelAndView) {
        modelAndView.setViewName("greeting/bye");
        return modelAndView;
    }
}
