package org.example.repository;

import jakarta.persistence.NamedEntityGraph;
import jakarta.persistence.QueryHint;
import org.example.dto.PersonalInfo2;
import org.example.entity.Role;
import org.example.entity.User;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.history.RevisionRepository;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long>,
        FilterUserRepository,
        RevisionRepository<User, Long, Integer>,
        QuerydslPredicateExecutor<User> {

    @Query(value = """
            select u from User u where u.firstname ilike %:firstname% and u.lastname ilike %:lastname%
            """)
    List<User> findAllBy(String firstname, String lastname);

    @Query(value = """
            SELECT *
            FROM users
            WHERE username ILIKE :username
                   """, nativeQuery = true)
    List<User> findAllByUsername(String username);

    @Modifying
    @Query(value = """
            update User u set u.role=:role
            where u.id in (:ids)
            """)
    int updateRole(Role role, Long... ids);

    @Modifying
    @Query(value = """
            update User u set u.role=:role
            where u.role in (:roles)
            """)
    int updateRoles(Role role, Role... roles);

    //    List<PersonalInfo> findAllByCompanyId(Integer id);
    <T> List<T> findAllByCompanyId(int id, Class<T> clazz);

    @Query(value = """
            SELECT firstname, lastname, birth_date birthDate FROM users
            WHERE company_id = :companyId
            """, nativeQuery = true)
    List<PersonalInfo2> findAllByCompanyId(Integer companyId);

    //    @Query(value = """
//            select u from User u join fetch u.company
//            """)
    @QueryHints({
            @QueryHint(name = "org.hibernate.cacheable", value = "true")
    })
    @EntityGraph(attributePaths = {"company.name"})
    List<User> findAll();

    @QueryHints({
            @QueryHint(name = "org.hibernate.cacheable", value = "true")
    })
    @Query(value = """
            select u from User u join fetch u.company
            where u.id=:id
            """)
//    @EntityGraph(attributePaths = {"company.name"})
    Optional<User> findById(Long id);

    Optional<User> findByUsername(String username);
}

