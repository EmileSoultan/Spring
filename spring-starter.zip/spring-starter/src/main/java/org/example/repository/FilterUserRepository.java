package org.example.repository;

import org.example.dto.PersonalInfo;
import org.example.dto.UserFilter;
import org.example.dto.UserReadDto;
import org.example.entity.Role;
import org.example.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface FilterUserRepository {

    List<User> findAllByFilter(UserFilter userFilter);

    List<PersonalInfo> findAllByCompanyIdAndRole(Integer companyId, Role role);

    void updateCompanyAndRole(List<User> users);


}
