package org.example.listener.entity;

public enum AccessType {
    CREATE, READ, UPDATE, DELETE
}
