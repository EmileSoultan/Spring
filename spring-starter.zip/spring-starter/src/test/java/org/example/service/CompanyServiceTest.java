package org.example.service;

import org.example.dto.CompanyReadDto;
import org.example.entity.Company;
import org.example.listener.entity.EntityEvent;
import org.example.repository.CompanyRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;

import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CompanyServiceTest {

    private static final Integer COMPANY_ID = 1;
    @Mock
    private CompanyRepository companyRepository;
    @Mock
    private UserService userService;
    @Mock
    private ApplicationEventPublisher eventPublisher;
    @InjectMocks
    private CompanyService companyService;

    @Test
    void findById() {
        when(companyRepository.findById(COMPANY_ID))
                .thenReturn(Optional.of( new Company(COMPANY_ID, null,null ,Collections.emptyList())));
        Optional<CompanyReadDto> actualResult = companyService.findById(COMPANY_ID);
        assertTrue(actualResult.isPresent());
        var expectedResult = new CompanyReadDto(COMPANY_ID, null);
        actualResult.ifPresent(actual -> assertEquals(expectedResult, actual));
        verify(eventPublisher).publishEvent(any(EntityEvent.class));
        verifyNoMoreInteractions(eventPublisher, userService);
    }

    @Test
    void testFindByIdWhenCompanyExistsThenReturnCompanyReadDto() {
        // Arrange
        Company company = new Company(COMPANY_ID,null,null, Collections.emptyList());
        when(companyRepository.findById(COMPANY_ID)).thenReturn(Optional.of(company));
        // Act
        Optional<CompanyReadDto> actualResult = companyService.findById(COMPANY_ID);
        // Assert
        assertTrue(actualResult.isPresent());
        assertEquals(new CompanyReadDto(COMPANY_ID,null), actualResult.get());
        verify(eventPublisher).publishEvent(any(EntityEvent.class));
        verifyNoMoreInteractions(eventPublisher, userService);
    }
}