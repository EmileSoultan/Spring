package org.example.integration.repository;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.example.dto.PersonalInfo;
import org.example.dto.PersonalInfo2;
import org.example.dto.UserFilter;
import org.example.entity.Company;
import org.example.entity.Role;
import org.example.entity.User;
import org.example.integration.IntegrationTestBase;
import org.example.integration.annotation.IntegrationTest;
import org.example.repository.CompanyRepository;
import org.example.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.test.annotation.Commit;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@RequiredArgsConstructor
class UserRepositoryTest extends IntegrationTestBase {

    private final CompanyRepository companyRepository;
    private final UserRepository userRepository;

    @Test
    void updateRole() {
        var resultCount = userRepository.updateRole(Role.USER, 1L, 5L);
        assertEquals(2, resultCount);
    }
    @Test
    void updateRoles() {
        var resultCount = userRepository.updateRoles(Role.USER, Role.ADMIN);
        assertEquals(2, resultCount);
    }

    @Test
    void checkQueries() {
        var users = userRepository.findAllBy("a", "ov");
        System.out.println(users);
    }

    @Test
    void checkSQLQueries() {
        var users = userRepository.findAllByUsername("%pe%");
        System.out.println(users);
    }

    @Test
    void checkBatch() {
        var users = userRepository.findAll();
        userRepository.updateCompanyAndRole(users);
        System.out.println();
    }

    @Test
    void checkJdbcTemplate() {
        var users = userRepository.findAllByCompanyIdAndRole(1, Role.USER);
        System.out.println();

    }

    @Test
    @Commit
    void checkAuditing() {
        var user = userRepository.findById(1L).get();
        user.setBirthdate(user.getBirthdate().plusYears(1L));
        userRepository.flush();
        System.out.println(user);
    }

    @Test
    void saveUser() {
        var company = companyRepository.findById(1).orElseThrow(EntityNotFoundException::new);
        var user = User.builder()
                .username("svetik@gmail.com")
                .firstname("Svetlana")
                .lastname("Rudova")
                .birthdate(LocalDate.of(1995, 5, 9))
                .role(Role.USER)
                .company(company)
                .build();
        userRepository.save(user);
        System.out.println();
    }

    @Test
    void checkProjections() {
        var users = userRepository.findAllByCompanyId(1, PersonalInfo2.class);
        System.out.println();
    }

    @Test
    void checkCustomImplementation() {
        var userFilter = new UserFilter(null, "%ov%", LocalDate.now());
        var users = userRepository.findAllByFilter(userFilter);
        System.out.println();
    }

    @Test
    void findAllByFilter() {
    }

    @Test
    void findById() {
        var user = userRepository.findById(1L);
        assertNotNull(user);
        assertThat(user.get().getUsername()).isEqualToIgnoringCase("ivan@gmail.com");
    }
}